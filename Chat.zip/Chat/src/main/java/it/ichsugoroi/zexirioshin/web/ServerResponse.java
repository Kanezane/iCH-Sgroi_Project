package it.ichsugoroi.zexirioshin.web;

public class ServerResponse {

    public void boh() {
    }
}
